import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [formData, setFormData] = useState({
    age: '', weight: '', gender: '', goal: '', lifestyle: '', zipcode: '', budget: ''
  });
  const [plan, setPlan] = useState('');
  const [stores, setStores] = useState([]);

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const { data } = await axios.post('/api/mealplan', formData);
    setPlan(data.plan);
    const storesRes = await axios.get(`/api/stores?zipcode=${formData.zipcode}`);
    setStores(storesRes.data.stores);
  };

  return (
    <div>
      <h1>AI-Powered Diet Planner</h1>
      <form onSubmit={handleSubmit}>
        {['age','weight','gender','goal','lifestyle','zipcode','budget'].map(field => (
          <input key={field} name={field} placeholder={field} onChange={handleChange} />
        ))}
        <button type="submit">Generate Plan</button>
      </form>

      {plan && (
        <div>
          <h2>Meal Plan & Shopping List</h2>
          <pre>{plan}</pre>
        </div>
      )}

      {stores.length > 0 && (
        <div>
          <h2>Nearby Grocery Stores</h2>
          <ul>{stores.map((s, i) => <li key={i}>{s}</li>)}</ul>
        </div>
      )}
    </div>
  );
}

export default App;
