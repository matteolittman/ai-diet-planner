require('dotenv').config();
const express = require('express');
const axios = require('axios');
const { Configuration, OpenAIApi } = require('openai');

const app = express();
app.use(express.json());

const openai = new OpenAIApi(new Configuration({
  apiKey: process.env.OPENAI_API_KEY
}));

const GOOGLE_PLACES_API_KEY = process.env.GOOGLE_PLACES_API_KEY;

app.post('/api/mealplan', async (req, res) => {
  const { age, weight, gender, goal, lifestyle, zipcode, budget } = req.body;

  const prompt = `You are a nutritionist. Create a detailed 2-week meal plan for:
  - Age: ${age}
  - Weight: ${weight} lbs
  - Gender: ${gender}
  - Goal: ${goal}
  - Lifestyle: ${lifestyle}

Include:
1. 3 meals and 1 snack per day for 14 days
2. A summarized shopping list of all ingredients with quantities
3. Ensure it's suitable for a grocery budget of $${budget}
`;

  try {
    const completion = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 2000
    });

    const plan = completion.data.choices[0].message.content;
    res.json({ plan });
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to generate plan');
  }
});

app.get('/api/stores', async (req, res) => {
  const { zipcode } = req.query;
  try {
    const locationRes = await axios.get(`https://maps.googleapis.com/maps/api/geocode/json?address=${zipcode}&key=${GOOGLE_PLACES_API_KEY}`);
    const { lat, lng } = locationRes.data.results[0].geometry.location;

    const placesRes = await axios.get(`https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${lat},${lng}&radius=5000&type=grocery_or_supermarket&key=${GOOGLE_PLACES_API_KEY}`);
    const stores = placesRes.data.results.map(store => store.name);

    res.json({ stores });
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to fetch stores');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
